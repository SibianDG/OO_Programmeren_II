package domein;

public interface MilieuBelasting {
	public final int MILEUHEFFING_ALLEENSTAANDE = 30;
	public final int MILEUHEFFING_GEZIN = 50;

	int berekenMilieuheffing();
}
