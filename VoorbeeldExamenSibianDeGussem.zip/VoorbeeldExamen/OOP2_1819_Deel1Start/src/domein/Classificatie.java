
package domein;

public enum Classificatie
{
    KLEIN, MIDDEL_GROOT, GROOT, ZEER_GROOT;
}
