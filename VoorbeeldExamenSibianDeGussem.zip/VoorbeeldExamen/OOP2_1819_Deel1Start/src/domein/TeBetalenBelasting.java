package domein;

public interface TeBetalenBelasting {

    double geefJaarlijkseBelasting();
}
