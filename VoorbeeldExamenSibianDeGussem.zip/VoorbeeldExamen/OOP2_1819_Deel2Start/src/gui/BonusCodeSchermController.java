package gui;

import domein.DomeinController;
import java.io.IOException;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;


public class BonusCodeSchermController extends GridPane
{

    @FXML
    private Label lblInvoer;
    @FXML
    private TextField txfEen;
    @FXML
    private TextField txfTwee;
    @FXML
    private Button btnControleer;
    @FXML
    private ComboBox<String> cmbKeuze;
    @FXML
    private Label lblReeks;

    @FXML
    private Label lblMessage;

    private DomeinController dc;
    private String gekozenItem;

    public BonusCodeSchermController(DomeinController dc)
    {
        this.dc = dc;

        FXMLLoader loader = new FXMLLoader(getClass().getResource("BonusCodeScherm.fxml"));
        loader.setRoot(this);
        loader.setController(this);

        try
        {
            loader.load();
        } catch (IOException ex)
        {
            throw new RuntimeException(ex);
        }

        cmbKeuze.setPromptText("Keuze?");
        cmbKeuze.setItems(FXCollections.observableArrayList("Een", "Reeks"));

    }

    @FXML
    private void btnControleer(ActionEvent event)
    {
        if (txfEen.getText() == null || txfEen.getText().isEmpty() || gekozenItem == null)
            lblMessage.setText("Maak eerst je keuze!");
        else {
            try {
                if (gekozenItem.equals("Een")) {
                    dc.registreerBonusCode(txfEen.getText());
                    lblMessage.setText("Correcte ingave bonusCode.");
                } else if (gekozenItem.equals("Reeks")) {
                    if (txfTwee.getText() == null || txfTwee.getText().isEmpty())
                        lblMessage.setText("Maak eerst je keuze!");
                    dc.registreerReeksBonusCodes(txfEen.getText(), txfTwee.getText());
                    if (dc.zijnOpeenvolgendeCodes()){
                        lblMessage.setText("Correcte ingave reeks bonusCodes.");
                    } else {
                        lblMessage.setText("Ingegeven reeks is niet correct.");
                    }
                }
            } catch (IllegalArgumentException iae) {
                lblMessage.setText(iae.getMessage());
            }

        }
    }

    @FXML
    private void cmbKeuzeOnAction(ActionEvent event)
    {
        gekozenItem = cmbKeuze.getSelectionModel().getSelectedItem();
        setReeksZichtbaar(!gekozenItem.equals("Een"));
    }

    private void setReeksZichtbaar(boolean aanAf)
    {
        lblReeks.setVisible(aanAf);
        txfTwee.setVisible(aanAf);
    }

}
