
package main;

import ui.Validate;


public class StartUp
{
    public static void main(String[] args)
    {
        new Validate().start();
    }
    
}
