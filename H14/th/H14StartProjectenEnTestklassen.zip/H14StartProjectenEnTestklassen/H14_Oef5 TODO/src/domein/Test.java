package domein;

public class Test {

    public static void main(String[] args) {
        MijnString mijnString = new MijnString("ac");
        System.out.println(mijnString.geefAllePermutatiesVanDrieMetStringBuilder());
    }
}
